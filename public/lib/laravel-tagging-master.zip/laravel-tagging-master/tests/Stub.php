<?php namespace Conner\Tagging\Tests;

use Conner\Tagging\Taggable;

class TaggingStub extends \Eloquent {
	use Taggable;
	
	function migrateAndSeed() {
		
	}
	
}